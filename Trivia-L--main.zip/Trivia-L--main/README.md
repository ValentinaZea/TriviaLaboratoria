# Trivia-L-
Codigo de trivia desarrollado en HTML, JS Y CSS

Contenido. El codigo final de este proyecto se encuentra dentro de la carpeta Trivia-L-

Desarrollo. para el diseño de este proyecto se combinaron las ideas de los bocetos que realizamos a mano individualmete,buscamos referecias de app de trivias (khoot,preguntados,quizizz), buscamos guias de estilo por internet y o fuimos aplicando a nuestro proyecto.
https://github.com/saragutierrez15/Trivia-L-/blob/main/Laboratoriaproyectofinal/img/WhatsApp%20Image%202021-01-21%20at%208.48.31%20AM.jpeg
https://github.com/saragutierrez15/Trivia-L-/blob/main/Laboratoriaproyectofinal/img/WhatsApp%20Image%202021-01-21%20at%208.49.15%20AM.jpeg
